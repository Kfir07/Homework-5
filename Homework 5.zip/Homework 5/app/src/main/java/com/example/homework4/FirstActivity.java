package com.example.homework4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class FirstActivity extends AppCompatActivity {

    Intent intent;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {//Menu Creation
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){//Menu items
        int id = item.getItemId();

        if (id==R.id.thirdPageEntry){
            intent = new Intent(FirstActivity.this,SecondActivity.class);//Intent creation between FirstActivity and SecondActivity
            intent.putExtra("FLAG","F");
            startActivity(intent);//Intent initiating
            finish();
            return true;
        }
        if (id==R.id.flagDenmark){
            intent = new Intent(FirstActivity.this,SecondActivity.class);//Intent creation between FirstActivity and SecondActivity
            intent.putExtra("FLAG","Denmark");
            startActivity(intent);//Intent initiating
            finish();
            return true;
        }
        if (id==R.id.flagMonaco){
            intent = new Intent(FirstActivity.this,SecondActivity.class);//Intent creation between FirstActivity and SecondActivity
            intent.putExtra("FLAG","Monaco");
            startActivity(intent);//Intent initiating
            finish();
            return true;
        }
        if (id==R.id.flagIsrael){
            intent = new Intent(FirstActivity.this,SecondActivity.class);//Intent creation between FirstActivity and SecondActivity
            intent.putExtra("FLAG","Israel");
            startActivity(intent);//Intent initiating
            finish();
            return true;
        }
        if (id==R.id.exitApp){
            finishAffinity();
            System.exit(0);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public static String NAME = "name", PASS = "password";//Strings for IDs of intent data transmitting
    EditText editTextName, editTextPass;
    Button send;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        Intent intent = getIntent();//Intent receiving
        editTextName = (EditText) findViewById(R.id.name);
        editTextPass = (EditText) findViewById(R.id.pass);//linking to xml EditText
        send = (Button) findViewById(R.id.send);//linking to xml button
        send.setOnClickListener(
                new View.OnClickListener() {//Listener - when button is pressed
                    @Override
                    public void onClick(View view) {
                        String name = editTextName.getText().toString();//Receiving String values from xml EditText
                        String password = editTextPass.getText().toString();
                        Intent intent = new Intent(FirstActivity.this, SecondActivity.class);//Intent creation between FirstActivity and SecondActivity
                        intent.putExtra(NAME, name);
                        intent.putExtra(PASS, password);//Intent data that will be transmitted
                        startActivity(intent);//Intent initiating
                    }

                });
    }
}
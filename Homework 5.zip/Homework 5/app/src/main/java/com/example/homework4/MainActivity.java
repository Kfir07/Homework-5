package com.example.homework4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;



import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Intent intent;
    Button next;
    CountDownTimer cdt;
    TextView counter;
    int maxTime = 10000, interval =1000;
    int count = maxTime/interval;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {//Menu Creation
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){//Menu items
        int id = item.getItemId();

        if (id==R.id.thirdPageEntry){
            intent = new Intent(MainActivity.this,SecondActivity.class);//Intent creation between MainActivity and SecondActivity
            intent.putExtra("FLAG","F");
            cdt.cancel();
            startActivity(intent);//Intent initiating
        }
        if (id==R.id.flagDenmark){
            intent = new Intent(MainActivity.this,SecondActivity.class);//Intent creation between MainActivity and SecondActivity
            intent.putExtra("FLAG","Denmark");
            cdt.cancel();
            startActivity(intent);//Intent initiating
        }
        if (id==R.id.flagMonaco){
            intent = new Intent(MainActivity.this,SecondActivity.class);//Intent creation between MainActivity and SecondActivity
            intent.putExtra("FLAG","Monaco");
            cdt.cancel();
            startActivity(intent);//Intent initiating
        }
        if (id==R.id.flagIsrael){
            intent = new Intent(MainActivity.this,SecondActivity.class);//Intent creation between MainActivity and SecondActivity
            intent.putExtra("FLAG","Israel");
            cdt.cancel();
            startActivity(intent);//Intent initiating
        }
        if (id==R.id.exitApp){
            cdt.cancel();
            finishAffinity();
            System.exit(0);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        counter = (TextView)findViewById(R.id.counter);//Timer creation and linking to xml TextView that will show it
        cdt=new CountDownTimer(maxTime,interval) {
            @Override
            public void onTick(long millisUntilFinished) {
                counter.setText(""+count);//Timer counting process
                count--;
            }

            @Override
            public void onFinish() {
                Toast.makeText(MainActivity.this,"Time is up ", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this,FirstActivity.class);//Intent creation between MainActivity and FirstActivity
                startActivity(intent);//Intent initiating
            }
        }.start();
        next = (Button)findViewById(R.id.next);//linking with xml button
        next.setOnClickListener(
                new View.OnClickListener(){//Listener - when the button is pressed
                    @Override
                    public void onClick(View view) {
                        cdt.cancel();
                        Intent intent = new Intent(MainActivity.this,FirstActivity.class);//Intent creation between MainActivity and FirstActivity
                        startActivity(intent);//Intent initiating
                    }

                });

    }


}